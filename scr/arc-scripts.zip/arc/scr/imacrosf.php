<?php
//
//	php -f /arc/scr/imacrosf.php
//	cp ~/nq/arc/imacros/spanking_* ~/iMacros/Macros/
//

//----------------------------------------------------
//
//			SET FILENAMES
//
//----------------------------------------------------
$pornBBFilename=		"/arc/imacros/spanking_sex_pornbb.iim";
$philiaFilename=		"/arc/imacros/spanking_sex_philia.iim";
$suzyFilename=			"";

$limitedFilename=		"/arc/imacros/spanking_sex_limited.iim";
$unlimitedFilename=		"/arc/imacros/spanking_sex_unlimited.iim";

$sourceFilename=		"spanking_sex.csv";

$limitedTime=           "3821";

//----------------------------------------------------
//
//			SET URLS
//
//----------------------------------------------------
$pornbb=				"http://fetish.pornbb.org/posting.php?mode=reply&t=1167285";
$forumophilia=			"http://www.forumophilia.com/posting.php?mode=reply&t=309307";
$planetsuzy_org=		"";

$vamateur=				"";
$myslavegirl=			"";
$bdsm_zone_com=			"http://bdsm-zone.com/newreply.php?do=newreply&noquote=1&p=6922937";
$pornw_org=				"http://www.porn-w.org/posting.php?mode=reply&f=2&t=7002247";
$fritchy_com=			"";
$intporn_org=			"http://www.intporn.org/threads/pornstar-fucks-a-fan-fuckafan-featuring-kagney-linn-karter.438930/";
$extreme_board_com=		"http://www.extreme-board.com/newreply.php?do=newreply&noquote=1&p=9267482";
$porno_maniac_net=		"http://porno-maniac.org/newreply.php?p=4969378&noquote=1";
$topboard_org=			"";
$kitty_kats_net=		"http://kitty-kats.net/newreply.php?p=6822385&noquote=1";
$pornshareproject_org=	"";
$vipergirls_to=			"http://vipergirls.to/newreply.php?p=5502399&noquote=1";
$extremal_board_com=	"";
$eight_teens_org=		"";
$incest_forum_com=		"";
$jdforum_org=			"";
$sexfetishforum_com=	"http://www.sexfetishforum.com/index.php?action=post;topic=766955.0;num_replies=4";
$linkindexxx_com=		"";
$final4ever=			"";
$elforro_com=			"";

$imCodeTop=
"SET !ERRORIGNORE YES\n".
"CMDLINE !DATASOURCE ".$sourceFilename."\n".
"SET !DATASOURCE_COLUMNS 6\n".
"SET !LOOP 1\n".
"SET !DATASOURCE_LINE {{!LOOP}}\n".
"SET !VAR1 0\n".
" \n";

$imCodePornbb="";
if($pornbb)
{
	$imCodePornbb = $imCodeTop;
	$imCodePornbb.=
	"URL GOTO=".$pornbb."\n".
	"WAIT SECONDS=4\n".
	"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:post ATTR=ID:prfsubj CONTENT={{!COL1}}\n".
	"WAIT SECONDS=5\n".
	"TAG POS=1 TYPE=TEXTAREA FORM=NAME:post ATTR=ID:ptres CONTENT={{!COL2}}\n".
	"WAIT SECONDS=15\n".
	"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:post ATTR=NAME:post\n".
	"WAIT SECONDS={{!COL4}}\n".
	" \n";
}


$imCodePhilia="";
if($forumophilia)
{
	$imCodePhilia = $imCodeTop;
	$imCodePhilia.=
	"URL GOTO=".$forumophilia."\n".
	"WAIT SECONDS=4\n".
	"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:post ATTR=NAME:subject CONTENT={{!COL1}}\n".
	"WAIT SECONDS=5\n".
	"TAG POS=1 TYPE=TEXTAREA FORM=NAME:post ATTR=NAME:message CONTENT={{!COL1}}\n".
	"WAIT SECONDS=15\n".
	"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:post ATTR=NAME:post\n".
	"WAIT SECONDS={{!COL5}}\n".
	" \n";
}

//******************************************************************
//
//        LIMITED AMMOUNT OF POSTS
//
//******************************************************************

$imCodeLimited="";
$imCodeLimited.=
"SET !ERRORIGNORE YES\n".
"CMDLINE !DATASOURCE ".$sourceFilename."\n".
"SET !DATASOURCE_COLUMNS 6\n".
"SET !LOOP 1\n".
"SET !DATASOURCE_LINE {{!LOOP}}\n".
"SET !VAR1 0\n".
" \n";


if($fritchy_com)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$fritchy_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

if($porno_maniac_net)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n" .
"TAB T={{!VAR1}}\n".
"URL GOTO=".$porno_maniac_net."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=ID:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=DIR:ltr&&TABINDEX:1&&ROLE:textbox&&ARIA-LABEL:Rich<SP>text<SP>editor,<SP>vB_Editor_001_editor,<SP>press<SP>ALT<SP>0<SP>for<SP>help.&&CLASS:cke_source<SP>cke_enable_context_menu&&TXT: CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

if($topboard_org)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$topboard_org."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

if($kitty_kats_net)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$kitty_kats_net."\n" .
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=ID:title CONTENT={{!COL1}}\n" .
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=DIR:ltr&&TABINDEX:1&&ROLE:textbox&&ARIA-LABEL:Rich<SP>text<SP>editor,<SP>vB_Editor_001_editor,<SP>press<SP>ALT<SP>0<SP>for<SP>help.&&CLASS:cke_source<SP>cke_enable_context_menu&&TXT: CONTENT={{!COL2}}\n" .
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n" .
" \n";
}


if($eight_teens_org)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$eight_teens_org."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=ID:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=DIR:ltr&&TABINDEX:1&&ROLE:textbox&&ARIA-LABEL:Rich<SP>text<SP>editor,<SP>vB_Editor_001_editor,<SP>press<SP>ALT<SP>0<SP>for<SP>help.&&CLASS:cke_source<SP>cke_enable_context_menu&&TXT: CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
"\n";
}


if($jdforum_org)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$jdforum_org."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
"\n";
}


if($final4ever)
{
$imCodeLimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$final4ever."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

$imCodeLimited.=
"WAIT SECONDS=".$limitedTime."\n".
"TAB CLOSEALLOTHERS\n";

//*****************************************************************
//
//           UNLIMITED UMMOUNT OF POSTS
//
//*****************************************************************

$imCodeUnlimited="";
$imCodeUnlimited.=
"SET !ERRORIGNORE YES\n".
"CMDLINE !DATASOURCE ".$sourceFilename."\n".
"SET !DATASOURCE_COLUMNS 6\n".
"SET !LOOP 1\n".
"SET !DATASOURCE_LINE {{!LOOP}}\n".
"SET !VAR1 0\n".
" \n";

if($vamateur)
{
$imCodeUnlimited.=
"URL GOTO=".$vamateur."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

if($myslavegirl)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$myslavegirl."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=ID:postmodify ATTR=NAME:subject CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=ID:postmodify ATTR=ID:message CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:postmodify ATTR=*\n".
"\n";
}


if($bdsm_zone_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$bdsm_zone_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
"\n";
}

if($pornw_org)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$pornw_org."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:postform ATTR=NAME:subject CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:postform ATTR=NAME:message CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:postform ATTR=NAME:post\n".
"\n";
}


if($intporn_org)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$intporn_org."\n".
"TAG POS=1 TYPE=A ATTR=HREF:javascript:void(null);\n".
"WAIT SECONDS=5\n".
"TAG POS=1 TYPE=TEXTAREA FORM=ID:QuickReply ATTR=NAME:message CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:QuickReply ATTR=*\n".
" \n";
}

if($extreme_board_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$extreme_board_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}


if($vipergirls_to)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$vipergirls_to."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=ID:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=DIR:ltr&&TABINDEX:1&&ROLE:textbox&&ARIA-LABEL:Rich<SP>text<SP>editor,<SP>vB_Editor_001_editor,<SP>press<SP>ALT<SP>0<SP>for<SP>help.&&CLASS:cke_source<SP>cke_enable_context_menu&&TXT: CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

if($extremal_board_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$extremal_board_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}


if($incest_forum_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$incest_forum_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=ID:postform ATTR=ID:subject CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=ID:postform ATTR=ID:message CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:postform ATTR=NAME:post\n".
"\n";
}


if($sexfetishforum_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$sexfetishforum_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=ID:postmodify ATTR=NAME:subject CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=ID:postmodify ATTR=NAME:message CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:postmodify ATTR=NAME:post\n".
"\n";
}


if($linkindexxx_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$linkindexxx_com."\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=ID:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=DIR:ltr&&TABINDEX:1&&ROLE:textbox&&ARIA-LABEL:Rich<SP>text<SP>editor,<SP>vB_Editor_001_editor,<SP>press<SP>ALT<SP>0<SP>for<SP>help.&&CLASS:cke_source<SP>cke_enable_context_menu&&TXT: CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
"\n";
}


if($elforro_com)
{
$imCodeUnlimited.=
"ADD !VAR1 1\n".
"TAB OPEN\n".
"TAB T={{!VAR1}}\n".
"URL GOTO=".$elforro_com."\n".
"TAG POS=1 TYPE=IMG ATTR=SRC:http://www.elforro.com/images/editor/switchmode.gif\n".
"WAIT SECONDS=5\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
" \n";
}

$imCodeUnlimited.=
"WAIT SECONDS={{!COL3}}\n".
"TAB CLOSEALLOTHERS\n";

//****************************************************************
//
//       PLANETSUZY
//
//****************************************************************

$imCodeSuzy="";

if($planetsuzy_org)
{
$imCodeSuzy.=
"SET !ERRORIGNORE YES\n".
"CMDLINE !DATASOURCE ".$sourceFilename."\n".
"SET !DATASOURCE_COLUMNS 6\n".
"SET !LOOP 1\n".
"SET !DATASOURCE_LINE {{!LOOP}}\n".
"URL GOTO=".$planetsuzy_org."\n".
"WAIT SECONDS=4\n".
"TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:vbform ATTR=NAME:title CONTENT={{!COL1}}\n".
"WAIT SECONDS=5\n".
"TAG POS=1 TYPE=TEXTAREA FORM=NAME:vbform ATTR=ID:vB_Editor_001_textarea CONTENT={{!COL2}}\n".
"WAIT SECONDS=15\n".
"TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:vbform ATTR=ID:vB_Editor_001_save\n".
"WAIT SECONDS={{!COL6}}\n".
" \n";
}


if($pornBBFilename && $imCodePornbb)file_put_contents($pornBBFilename, $imCodePornbb);
if($philiaFilename && $imCodePhilia)file_put_contents($philiaFilename, $imCodePhilia);
if($suzyFilename && $imCodeSuzy)file_put_contents($suzyFilename, $imCodeSuzy);

if($limitedFilename && $imCodeLimited)file_put_contents($limitedFilename, $imCodeLimited);
if($unlimitedFilename && $imCodeUnlimited)file_put_contents($unlimitedFilename, $imCodeUnlimited);
